# Elden Ring Review

A Pen created on CodePen.io. Original URL: [https://codepen.io/IsaMez/pen/rNJywOa](https://codepen.io/IsaMez/pen/rNJywOa).

